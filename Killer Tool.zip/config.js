module.exports = {
    numberOfRegisterInOneTime: 6, // no of registration want to make in one command.
    domains: ["lamoshitt.com", "crazzybabe.com"], // names of domain for the emails. 
    oneTimeMailGen: 10 * 100000,
    telegramBotToken: "7973668642:AAEUQDV5J3UFJ067FyScyVWZxACBw4Fv7gw", // bot token of telegram bot. Create a bot using https://t.me/BotFather then generate the token of the bot.
    adminNamesForTelegramBot: ["Baign_Baign","Baign_Baign"], // name of the admin/developer who's name will be displayed when any unknown user use the command of the bot in telegram.
    authorisedUserForTelegramBot: ["Baign_Baign","Baign_Baign"] // username or id of the user who can use the bot.
};